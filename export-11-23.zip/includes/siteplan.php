<div class="container-fluid siteplan">

  <div class="row">

    <div class="intro col-xs-12 col-sm-10 col-sm-offset-1 col-md-4 col-md-offset-1 col-lg-3 col-lg-offset-2">
      <h2>Siteplan</h2>
      <p>
        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
      </p>
      <ul class="legend">
        <li><div class="swatch swatch-villas"></div>Villas</li>
        <li><div class="swatch swatch-towns"></div>Towns</li>
      </ul>
    </div>

    <div class="map col-xs-12 col-sm-10 col-sm-offset-1 col-md-6 col-md-offset-0 col-lg-5">
      <img id="siteplan" class="img img-responsive center-block" src="img/doon-south-siteplan.jpg" alt="siteplan" />
    </div>

  </div>

</div>
